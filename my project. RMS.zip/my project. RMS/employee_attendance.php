<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from form
    $staff_number = $_POST['staff_number'];
    $name = $_POST['name'];
    $role = $_POST['role'];

    // SQL to insert employee
    $sql = "INSERT INTO employee_schedule (staff_number, name, role) VALUES ('$staff_number', '$name', '$role')";

    if ($conn->query($sql) === TRUE) {
        echo "New employee added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
</head>
<body>
    <h2>Add Employee</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="staff_number">Staff Number:</label><br>
        <input type="text" id="staff_number" name="staff_number"><br><br>

        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br><br>

        <label for="role">Role:</label><br>
        <input type="text" id="role" name="role"><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
