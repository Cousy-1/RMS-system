<?php
session_start(); // Start session to access session variables

// Check if the user is already logged in
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // If logged in, redirect to homepage or any other desired page
    header("Location: rms_homepage.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; 
$database = "rms_db";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Login process
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if email and password are set in the $_POST array
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Your login logic here

        // Assuming login is successful, set session variables
        $_SESSION['logged_in'] = true;
        // You can also store other user information in session variables if needed
        // $_SESSION['user_email'] = $user_email;

        // Redirect the user to the homepage or any other desired page
        header("Location: rms_homepage.php");
        exit();
    } else {
        // Handle case where email or password is not set in $_POST
        echo "Email or password is missing.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
             font-family: Arial, sans-serif;
            background-image: url('OIP.jpeg');
            background-size: cover; /* Ensure the background image covers the entire body */
            background-repeat: no-repeat; /* Prevent the background image from repeating */
            line-height: 1.6;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #e44d26;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #e44d26;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #c93f1a;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <?php if(!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) { ?>
    <!-- Show login form only if the user is not logged in -->
    <div class="container">
        <h2>Login</h2>
        <form method="post" action="login_rms.php">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Login">
        </form>
        <p>Don't have an account? <a href="signup_rms.php">Signup</a></p>
        <p>Login as Admin? <a href="admin_loginrms.php">Login as Admin</a></p>
    </div>
    <?php } ?>
</body>
</html>
