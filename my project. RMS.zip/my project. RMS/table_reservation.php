<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db"; // Adjust this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from form
    $customer_name = $_POST['customer_name'];
    $reservation_date = $_POST['reservation_date'];
    $reservation_time = $_POST['reservation_time'];
    $party_size = $_POST['party_size'];

    // SQL to insert reservation
    $sql = "INSERT INTO reservations (customer_name, reservation_date, reservation_time, party_size) VALUES ('$customer_name', '$reservation_date', '$reservation_time', '$party_size')";

    if ($conn->query($sql) === TRUE) {
        echo "Reservation added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Table Reservation</title>
</head>
<body>
    <h2>Table Reservation</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="table_id">Your Name:</label><br>
        <input type="text" id="customer_name" name="customer_name" required><br><br>
        
        <label for="reservation_date">Date:</label><br>
        <input type="date" id="reservation_date" name="reservation_date" required><br><br>

        <label for="reservation_time">Time:</label><br>
        <input type="time" id="reservation_time" name="reservation_time" required><br><br>

        <label for="party_size">Party Size:</label><br>
        <input type="number" id="party_size" name="party_size" min="1" required><br><br>

        <input type="submit" value="Reserve Table">
    </form>
</body>
</html>
