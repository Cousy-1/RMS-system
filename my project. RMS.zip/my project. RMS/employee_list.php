<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from form
    $name = $_POST['name'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $gender = $_POST['gender']; // Add gender field

    // Check if the email already exists
    $sql_check_email = "SELECT * FROM employees WHERE email = '$email'";
    $result_check_email = $conn->query($sql_check_email);

    if ($result_check_email->num_rows > 0) {
        echo "Error: Email already exists";
    } else {
        // SQL to insert employee
        $sql = "INSERT INTO employees (name, role, email, phone_number, gender) VALUES ('$name', '$role', '$email', '$phone_number', '$gender')";

        if ($conn->query($sql) === TRUE) {
            echo "New employee added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// SQL to fetch employees
$sql_fetch_employees = "SELECT * FROM employees";
$result_employees = $conn->query($sql_fetch_employees);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee Management</title>
</head>
<body>
    <h2>Add Employee</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br><br>

        <label for="role">Role:</label><br>
        <input type="text" id="role" name="role"><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email"><br><br>

        <label for="phone_number">Phone:</label><br>
        <input type="text" id="phone_number" name="phone_number"><br><br>

        <label for="gender">Gender:</label><br> <!-- Add gender field -->
        <select id="gender" name="gender">
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>

    <h2>Employee List</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th> <!-- Add gender column header -->
        </tr>
        <?php
        if ($result_employees->num_rows > 0) {
            // Output data of each row
            while ($row = $result_employees->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["employee_id"] . "</td>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["role"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["phone_number"] . "</td>";
                echo "<td>" . $row["gender"] . "</td>"; // Add gender data
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No employees found</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
