<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Inventory Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .inventory-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .inventory-item p {
            margin: 5px 0;
        }

        .low-stock {
            background-color: #ffe6e6;
        }

        button {
            padding: 8px 16px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Restaurant Inventory Management</h1>
    <div class="container">
        <div id="inventory-list">
            <!-- Inventory items will be populated here dynamically -->
        </div>
        <h2>Usage</h2>
        <form id="usage-form">
            <label for="item-name">Item Name:</label>
            <select id="item-name" name="item-name" required>
                <option value="Flour">Flour</option>
                <option value="Chicken">Chicken</option>
                <option value="Beef">Beef (in kg)</option>
                <option value="Beverages">Beverages</option>
                <option value="Rice">Rice</option>
                <option value="Wheat Flour">Wheat Flour</option>
                <option value="Sugar">Sugar</option>
                <option value="Sauces">Sauces</option>
            </select>

            <label for="quantity">Quantity to Subtract:</label>
            <input type="number" id="quantity" name="quantity" min="1" required>

            <input type="submit" value="Submit">
        </form>
    </div>

    <script>
        // Sample inventory data (to be fetched from a database in real scenario)
        let inventoryItems = [
            { name: "Flour", quantity: 50, threshold: 20 },
            { name: "Chicken", quantity: 20, threshold: 10 },
            { name: "Beef", quantity: 30, threshold: 15 },
            { name: "Beverages", quantity: 40, threshold: 20 },
            { name: "Rice", quantity: 25, threshold: 10 },
            { name: "Wheat Flour", quantity: 20, threshold: 10 },
            { name: "Sugar", quantity: 40, threshold: 15 },
            { name: "Sauces", quantity: 15, threshold: 5 }
            // Add more items as needed
        ];

        // Function to render inventory items
        function renderInventory() {
            const inventoryList = document.getElementById('inventory-list');
            inventoryList.innerHTML = '';

            inventoryItems.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.classList.add('inventory-item');
                itemElement.innerHTML = `
                    <p>Name: ${item.name}</p>
                    <p>Quantity: ${item.quantity}</p>
                    <p>Refill Threshold: ${item.threshold}</p>
                    <button onclick="refillItem('${item.name}')">Refill</button>
                `;
                if (item.quantity <= item.threshold) {
                    itemElement.classList.add('low-stock');
                }
                inventoryList.appendChild(itemElement);
            });
        }

        // Function to refill an item
        function refillItem(name) {
            const item = inventoryItems.find(item => item.name === name);
            if (item) {
                item.quantity += 10; // Assuming a fixed refill quantity for demonstration
                renderInventory();
            }
        }

        // Function to handle form submission
        document.getElementById('usage-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            // Retrieve form data
            const itemName = document.getElementById('item-name').value;
            const quantity = parseInt(document.getElementById('quantity').value);

            // Call a function to update inventory (for demonstration purposes, just log the data)
            updateInventory(itemName, quantity);

            // Clear form fields
            document.getElementById('quantity').value = '';
        });

        // Function to update inventory (replace with actual backend logic)
        function updateInventory(itemName, quantity) {
            const item = inventoryItems.find(item => item.name === itemName);
            if (item) {
                item.quantity -= quantity; // Subtract the quantity
                renderInventory(); // Update the inventory display
            }
        }

        // Initial rendering
        renderInventory();
    </script>
</body>
</html>
