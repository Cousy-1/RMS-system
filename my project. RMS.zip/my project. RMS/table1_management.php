<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Status Management</title>
    <style>
        /* Style for the tables */
        .table {
            width: 100px;
            height: 100px;
            margin: 10px;
            float: left;
            border: 2px solid #000;
            text-align: center;
            line-height: 100px;
            font-size: 20px;
            cursor: pointer; /* Add cursor pointer to indicate clickable */
            transition: background-color 0.3s ease; /* Add transition for smooth color change */
            position: relative; /* Position relative for adding icons */
        }

        /* Style for different table statuses */
        .occupied {
            background-color: green;
        }

        .empty {
            background-color: red;
        }

        .reserved {
            background-color: orange;
        }

        /* Style for status text */
        .status-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* Style for dropdown */
        .status-dropdown {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: none; /* Initially hidden */
        }
    </style>
</head>
<body>
    <h1>Table Status Management</h1>

    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "rms_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to generate table square based on status
    function generateSquare($status, $table_id) {
        return "<div class='table $status' data-status='$status' data-table-id='$table_id' onclick='changeTableStatus(this)'></div>";
    }

    // Define the function to fetch tables from the database
    function fetchTables($conn) {
        // Query to select all tables
        $sql = "SELECT * FROM tables";
        $result = $conn->query($sql);

        // Check if there are any rows returned
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                // Output the table as a clickable div with the appropriate class based on its status
                echo generateSquare($row["status"], $row["table_id"]);
            }
        } else {
            echo "0 results";
        }
    }

    // Output existing tables
    fetchTables($conn);

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Process table status changes
        if (!empty($_POST['table_id']) && !empty($_POST['table_status'])) {
            $table_ids = $_POST['table_id'];
            $table_statuses = $_POST['table_status'];

            // Update table statuses in the database
            for ($i = 0; $i < count($table_ids); $i++) {
                $table_id = $table_ids[$i];
                $status = $table_statuses[$i];

                $sql_update_table_status = "UPDATE tables SET status='$status' WHERE table_id=$table_id";
                $conn->query($sql_update_table_status);
            }
        }

        // Process adding new tables
        if (!empty($_POST['new_table_count'])) {
            $new_table_count = intval($_POST['new_table_count']);

            // Insert new tables into the database with default status as 'empty'
            for ($i = 0; $i < $new_table_count; $i++) {
                $sql_insert_table = "INSERT INTO tables (status) VALUES ('empty')";
                $conn->query($sql_insert_table);
            }
        }
    }
    ?>

    <script>
        // Function to change the table status
        function changeTableStatus(table) {
            var currentStatus = table.getAttribute('data-status'); // Get the current status
            var newStatus = "";

            // Determine the new status based on the current status
            if (currentStatus === "occupied") {
                newStatus = "empty";
            } else if (currentStatus === "empty") {
                newStatus = "reserved";
            } else if (currentStatus === "reserved") {
                newStatus = "occupied";
            }

            // Update the table status visually
            table.classList.remove(currentStatus);
            table.classList.add(newStatus);
            table.setAttribute('data-status', newStatus);

            // Send an AJAX request to update the database
            var tableId = table.getAttribute('data-table-id');
            var formData = new FormData();
            formData.append('table_id', tableId);
            formData.append('table_status', newStatus);

            fetch('update_table_status.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => console.log(result))
            .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
