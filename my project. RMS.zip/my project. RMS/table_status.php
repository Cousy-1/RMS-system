<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db"; // Adjust this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch table status
$sql = "SELECT * FROM tables";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Table Status</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .occupied {
            background-color: #ff9999;
        }
        .available {
            background-color: #99ff99;
        }
    </style>
</head>
<body>
    <h2>Table Status</h2>
    <table>
        <thead>
            <tr>
                <th>Table Number</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["table_number"] . "</td>";
                    // Check if the table is occupied or available
                    if ($row["is_occupied"] == 1) {
                        echo "<td class='occupied'>Occupied</td>";
                    } else {
                        echo "<td class='available'>Available</td>";
                    }
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No tables found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
