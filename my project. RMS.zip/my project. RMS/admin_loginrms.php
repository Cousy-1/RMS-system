<?php
session_start(); // Start the session

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the staff number, email, and password are provided
    if (!empty($_POST["staff_no"]) && !empty($_POST["email"]) && !empty($_POST["password"])) {
        // Extract the provided data and sanitize inputs
        $staff_no = $conn->real_escape_string($_POST["staff_no"]);
        $email = $conn->real_escape_string($_POST["email"]);
        $password = $conn->real_escape_string($_POST["password"]);

        // Hash the password (assuming it's stored as plaintext in the database)
        // $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Validate the login 
        $sql = "SELECT * FROM employees WHERE staff_no = '$staff_no' AND email = '$email' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows == 1) {
            // Successful login
            $_SESSION["loggedin"] = true; // Set session variable to indicate user is logged in
            header("Location: rmsadmin_dashboard.php"); // Redirect to dashboard
            exit; // Stop further execution
        }
    } else {
        // If any field is empty
        $error_message = "Please fill in all fields.";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Login</h2>
        <?php if (isset($error_message)) : ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="staff_no">Staff No:</label>
            <input type="text" name="staff_no" required>

            <label for="email">Email:</label>
            <input type="email" name="email" required>
            

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
