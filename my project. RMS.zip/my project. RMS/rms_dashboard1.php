<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch data from the database
function fetchData($conn, $table) {
    $sql = "SELECT * FROM $table";
    $result = $conn->query($sql);
    $data = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

// Fetch data from tables
$menuData = fetchData($conn, 'menu');
$inventoryData = fetchData($conn, 'inventory');
$employeeData = fetchData($conn, 'employees');
$tablesData = fetchData($conn, 'tables');
$employeeScheduleData = fetchData($conn, 'employee_schedule');

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            line-height: 1.6;
            text-align: center;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
            margin-bottom: 30px;
        }

        h1 {
            color: #e44d26;
            margin-bottom: 20px;
        }

        section {
            flex: 1;
            padding: 0 20px;
        }

        .container {
            background-color: orange;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            text-align: left;
        }

        .container h2 {
            color: #343a40;
            margin-bottom: 10px;
        }

        .container ul {
            list-style: none;
            padding-left: 0;
        }

        .container ul li {
            margin-bottom: 10px;
        }

        footer {
            background-color: #343a40;
            color: #fff;
            padding: 20px 0;
        }

        .social-icons a {
            margin: 0 10px;
        }

        .social-icons img {
            width: 30px;
            height: 30px;
            vertical-align: middle;
        }
    </style>
</head>
<body>

<header>
    <h1>Dashboard</h1>
</header>

<section>
    <div class="container">
        <h2>Menu</h2>
        <ul>
            <?php foreach ($menuData as $item): ?>
                <li><?php echo isset($item['food']) ? $item['food'] : 'N/A'; ?>  - <?php echo isset($item['category']) ? $item['category'] : 'N/A'; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="container">
        <h2>Inventory</h2>
        <ul>
            <?php foreach ($inventoryData as $item): ?>
                <li><?php echo isset($item['name']) ? $item['name'] : 'N/A'; ?> - Quantity: <?php echo isset($item['quantity']) ? $item['quantity'] : 'N/A'; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="container">
        <h2>Employees</h2>
        <ul>
            <?php foreach ($employeeData as $employee): ?>
                <li><?php echo isset($employee['name']) ? $employee['name'] : 'N/A'; ?> - <?php echo isset($employee['role']) ? $employee['role'] : 'N/A'; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="container">
        <h2>Tables</h2>
        <ul>
            <?php foreach ($tablesData as $table): ?>
                <li>Table <?php echo isset($table['table_id']) ? $table['table_id'] : 'N/A'; ?> - Status: <?php echo isset($table['status']) ? $table['status'] : 'N/A'; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="container">
        <h2>Employee Schedule</h2>
        <ul>
            <?php foreach ($employeeScheduleData as $schedule): ?>
                <li><?php echo isset($schedule['name']) ? $schedule['name'] : 'N/A'; ?> - <?php echo isset($schedule['shift_date']) ? $schedule['shift_date'] : 'N/A'; ?> -  - <?php echo isset($schedule['start_time']) ? $schedule['end_time'] : 'N/A'; ?> -  - <?php echo isset($schedule['employee_id']) ? $schedule['employee_id'] : 'N/A'; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<footer>
    <p>&copy; 2024 Restaurant Management System</p>
    <p>Connect with us on</p>
    <div class="social-icons">
        <a href="#" target="_blank"><img src="x.png" alt="Twitter"></a>
        <a href="#" target="_blank"><img src="i.jpg" alt="Instagram"></a>
        <a href="#" target="_blank"><img src="f.png" alt="Facebook"></a>
        <a href="#" target="_blank"><img src="l.png" alt="LinkedIn"></a>
    </div>
</footer>

</body>
</html>
