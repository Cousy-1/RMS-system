<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; 
$database = "rms_db";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to list and display employees
function displayEmployees() {
    global $conn;
    $sql = "SELECT * FROM employees";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<h2>Employee List</h2>";
        echo "<table>";
        echo "<tr><th>Employee ID</th><th>Name</th><th>Role</th><th>Email</th><th>Phone Number</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row["employee_id"]."</td><td>".$row["name"]."</td><td>".$row["role"]."</td><td>".$row["email"]."</td><td>".$row["phone_number"]."</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No employees found.";
    }
}

// Function to manage employee work schedules
function manageWorkSchedules() {
    echo "<h2>Manage Employee Work Schedules</h2>";
    // Add your code here for managing work schedules
}

// Function to track employee attendance
function trackAttendance() {
    echo "<h2>Track Employee Attendance</h2>";
    // Add your code here for tracking attendance
}

// Check which page to display based on the request
if(isset($_GET['page'])) {
    $page = $_GET['page'];
    switch($page) {
        case 'employee_list':
            displayEmployees();
            break;
        case 'employee_schedule':
            manageWorkSchedules();
            break;
        case 'employee_attendance':
            trackAttendance();
            break;
        default:
            echo "Invalid page.";
    }
} else {
    echo "No page requested.";
}

// Close connection
$conn->close();
?>
