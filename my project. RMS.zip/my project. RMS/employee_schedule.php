<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to fetch employee schedules
$sql_fetch_schedules = "SELECT employee_id, name, shift_date, start_time, end_time FROM employee_schedule";
$result_schedules = $conn->query($sql_fetch_schedules);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Schedule</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Employee Schedule</h2>

<table>
    <tr>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Shift Date</th>
        <th>Start Time</th>
        <th>End Time</th>
    </tr>
    <?php
    if ($result_schedules->num_rows > 0) {
        // Output data of each row
        while ($row = $result_schedules->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["employee_id"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["shift_date"] . "</td>";
            echo "<td>" . $row["start_time"] . "</td>";
            echo "<td>" . $row["end_time"] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No schedules found</td></tr>";
    }
    ?>
</table>

</body>
</html>

<?php
// Close connection
$conn->close();
?>
