<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
    font-family: Arial, sans-serif;
            background-image: url('R.jpeg');
            background-size: cover; /* Ensure the background image covers the entire body */
            background-repeat: no-repeat; /* Prevent the background image from repeating */
            line-height: 1.6;
    text-align: center;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}


        h1 {
            color: #e44d26;
            margin-top: 50px;
        }

        nav {
            background-color: red; /* Change to red */
            padding: 10px 0;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #495057;
        }

        section {
            padding: 50px 0;
            flex: 1; /* Allow section to grow to fill available space */
        }

        h2 {
            color:#fff;
            margin-bottom: 20px;
        }

        .containers {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 30px;
        }

        .container {
            background-color:#fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .container h2 {
            color: #343a40;
            margin-bottom: 100px;
        }

        .container p {
            color: #6c757d;
            margin-bottom: 100px;
        }

        footer {
            background-color: #343a40;
            color: #fff;
            padding: 20px;
            margin-top: auto; /* Push footer to the bottom */
        }

        .social-icons a {
            margin: 0 10px;
        }

        .social-icons img {
            width: 30px;
            height: 30px;
            vertical-align: middle;
        }
    </style>
</head>
<body>

<h1>Homepage</h1>

<nav>
    <?php
    // Start session to access session variables
    session_start();

    // Check if user is logged in
    if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
        // User is logged in, display navigation links
        echo '<a href="our_menu.php">Menu</a>';
        echo '<a href="table_management.php">Tables</a>';
        echo '<a href="rms_dashboard1.php">Dashboard</a>';
        echo '<a href="signout_rms.php">Logout</a>';
    } else {
        // User is not logged in, display login link
        echo '<a href="login_rms.php">Login</a>';
    }
    ?>
</nav>

<section>
    <h2>Welcome to our homepage</h2>
    <p>We are thrilled to have you onboard.<br> We're delighted to have you here.<br>Login to explore more</p>
</section>

<?php
// Check if user is logged in
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // User is logged in, display additional sections
    echo '<div class="containers">';
    echo '<div class="container">';
    echo '<h2>Table Status</h2>';
    echo '<p><a href="table_management.php">Check table availability</a></p>';
    echo '</div>';
    echo '<div class="container">';
    echo '<h2>Menu</h2>';
    echo '<p><a href="our_menu.php">Today\'s menu</a></p>';
    echo '</div>';
    echo '<div class="container">';
    echo '<h2>Employee Schedule</h2>';
    echo '<p><a href="employee_schedule.php">View Your Schedule</a></p>';
    echo '</div>';
    // Add more containers with relevant links
    echo '</div>';
}
?>

<footer>
    <p>&copy; 2024 Restaurant Management System</p>
    <p>Connect with us on</p>
    <div class="social-icons">
        <a href="#" target="_blank"><img src="https://th.bing.com/th/id/OIP.YGJYM4pqXxVMHzPYfdLumgHaHa?w=178&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Twitter"></a>
        <a href="#" target="_blank"><img src="https://th.bing.com/th/id/OIP.2spOcwGpwKFSn-ZDDhdeIgHaHd?w=175&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Instagram"></a>
        <a href="#" target="_blank"><img src="https://th.bing.com/th/id/OIP.XW6jinaUmN_Bn-Y4nRTbOQHaHa?w=189&h=189&c=7&r=0&o=5&dpr=1.3&pid=1.7g" alt="Facebook"></a>
        <a href="#" target="_blank"><img src="https://th.bing.com/th/id/OIP.w_zDkEJ9aLiWR-g0rff8hwHaHa?w=204&h=204&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="LinkedIn"></a>
    </div>
</footer>

</body>
</html>
