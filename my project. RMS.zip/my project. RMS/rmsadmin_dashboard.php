<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Management System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex; /* Use flexbox for layout */
            flex-direction: column; /* Arrange elements in a column */
            align-items: center; /* Center elements horizontally */
            height: 100vh; /* Ensure the page takes up the full viewport height */
            background-color: #9966ff; /* Add a background color for better visibility */
        }
        h1 {
            margin-top: 20px; /* Add space above the heading */
        }
        .containers {
            display: flex; /* Use flexbox for containers */
            flex-wrap: wrap; /* Allow containers to wrap to the next line */
            justify-content: center; /* Center containers horizontally */
            gap: 20px; /* Add space between containers */
        }
        .container {
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            width: 200px; /* Adjust the width as needed */
            height: 200px; /* Adjust the height as needed */
            text-align: center;
            transition: transform 0.3s ease; /* Add transition for smooth hover effect */
        }
        h2 {
            margin-top: 0;
        }
        .container:nth-child(odd) {
            background-color: #8A2BE2; /* Adjust the color as needed */
            color: black; /* Text color */
        }
        .container:nth-child(even) {
            background-color: #FFD700; /* Adjust the color as needed */
        }
        /* Add hover effect */
        .container:hover {
            transform: translateY(-10px); /* Move the container up by 10 pixels */
        }
    </style>
</head>
<body>
    <h1>Welcome to Admin Dashboard</h1>
    <nav>
     <a href="rms_homepage.php">Home</a>
     </nav>
    <div class="containers">
        <div class="container">
            <h2>Employees</h2>
            <p><a href="employee_list.php">Employee List and Management</a></p>
            
            
        </div>
        <div class="container">
            <h2>Inventory Management</h2>
            <p><a href="menu_management.php">Menu Management</a></p>
            <p><a href="rms_stock.php">Restock</a></p>
            
        </div>
        <div class="container">
            <h2>Tables</h2>
            <p><a href="table_management.php">Display and manage table status</a></p>
           
        </div>
        <div class="container">
            <h2>Enquiries</h2>
            <p><a href="admin_enquiries.php">Reply to Equiries</a></p>
        </div>
    </div>
</body>
</html>
