<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Usage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="text"],
        input[type="number"],
        input[type="submit"] {
            margin-bottom: 10px;
            padding: 8px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inventory Usage</h2>
        <form id="usage-form">
            <label for="item-name">Item Name:</label>
            <input type="text" id="item-name" name="item-name" required>

            <label for="quantity">Quantity to Subtract:</label>
            <input type="number" id="quantity" name="quantity" min="1" required>

            <input type="submit" value="Submit">
        </form>
    </div>

    <script>
        // Function to handle form submission
        document.getElementById('usage-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            // Retrieve form data
            const itemName = document.getElementById('item-name').value;
            const quantity = parseInt(document.getElementById('quantity').value);

            // Call a function to update inventory (for demonstration purposes, just log the data)
            updateInventory(itemName, quantity);

            // Clear form fields
            document.getElementById('item-name').value = '';
            document.getElementById('quantity').value = '';
        });

        // Function to update inventory (replace with actual backend logic)
        function updateInventory(itemName, quantity) {
            console.log(`Subtracting ${quantity} of ${itemName} from inventory.`);
            // Here you would typically send a request to your backend to update the inventory
            
        }
    </script>
</body>
</html>
