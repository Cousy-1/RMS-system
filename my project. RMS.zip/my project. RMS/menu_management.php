<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "rms_db"; // Adjust this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from form
    $food = $_POST['dish'];
    $price = $_POST['price'];
    $category = $_POST['category']; // New field for category

    // SQL to insert menu item
    $sql = "INSERT INTO menu (food, price, category) VALUES ('$food', '$price', '$category')";

    if ($conn->query($sql) === TRUE) {
        echo "Menu item added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Retrieve menu items from the database
$sql = "SELECT food, price, category FROM menu";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Menu Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-top: 20px;
        }

        form {
            margin: 20px auto;
            width: 50%;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .menu-table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        .menu-table th,
        .menu-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .menu-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Menu Management</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="food">Food:</label><br>
        <input type="text" id="dish" name="dish" required><br><br>

        <label for="price">Price:</label><br>
        <input type="number" id="price" name="price" min="0.01" step="0.01" required><br><br>

        <label for="category">Category:</label><br>
        <select id="category" name="category" required>
            <option value="">Select a category</option>
            <option value="Main Course">Main Course</option>
            <option value="Beverages">Beverages</option>
            <option value="Desserts">Desserts</option>
            <option value="Breakfast">Breakfast</option>
            <option value="Dinner">Dinner</option>
            <option value="Specials">Specials</option>
        </select><br><br>

        <input type="submit" value="Add Menu Item">
    </form>

    <table class="menu-table">
        <thead>
            <tr>
                <th>Food</th>
                <th>Price(KES)</th>
                <th>Category</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $food = $row['food']; // Changed from 'dish' to 'food'
                    $price = $row['price'];
                    $category = $row['category'];

                    // Display menu item
                    echo "<tr>";
                    echo "<td>$food</td>";
                    echo "<td>$price</td>";
                    echo "<td>$category</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No menu items found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
